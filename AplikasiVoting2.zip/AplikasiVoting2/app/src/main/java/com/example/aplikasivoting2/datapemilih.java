package com.example.aplikasivoting2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class datapemilih extends AppCompatActivity {
    private DBManager dbManager;
    private ListView listView;
    private SimpleCursorAdapter adapter;
    final String[] from = new String[]{DatabaseHelper._ID,
            DatabaseHelper.NAMA, DatabaseHelper.KELAS, DatabaseHelper.CHOICE
    };
    final int[] to = new int[]{R.id.id, R.id.nama, R.id.kelas, R.id.choice};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datapemilih);
        dbManager = new DBManager(this);
        dbManager.open();
        Cursor cursor = dbManager.fetch();
        listView = (ListView) findViewById(R.id.list_view);
        listView.setEmptyView(findViewById(R.id.empty));

        adapter = new SimpleCursorAdapter(this, R.layout.activity_fragment,
                cursor, from, to, 0);
        adapter.notifyDataSetChanged();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int
                    position, long viewId) {
                TextView idTextView = (TextView) view.findViewById(R.id.id);
                TextView namaTextView = (TextView) view.findViewById(R.id.nama);
                TextView kelasTextView = (TextView) view.findViewById(R.id.kelas);
                TextView choiceTextView = (TextView) view.findViewById(R.id.choice);

                String id = idTextView.getText().toString();
                String nama = namaTextView.getText().toString();
                String kelas = kelasTextView.getText().toString();
                String choice = choiceTextView.getText().toString();

                Intent modify_intent = new Intent(getApplicationContext(),
                        ModifyPemilih.class);
                modify_intent.putExtra("kelas", kelas);
                modify_intent.putExtra("nama", nama);
                modify_intent.putExtra("id", id);
                modify_intent.putExtra("choice", choice);
                startActivity(modify_intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu2, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add_record) {
            Intent add_mem = new Intent(this, MainActivity.class);
            startActivity(add_mem);
        }
        return super.onOptionsItemSelected(item);
    }
}