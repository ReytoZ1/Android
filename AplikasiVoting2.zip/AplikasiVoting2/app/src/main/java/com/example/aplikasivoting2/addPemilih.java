package com.example.aplikasivoting2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class addPemilih extends AppCompatActivity {
    private Button addTodoBtn;
    private EditText kelasEditText;
    private EditText namaEditText;
    private EditText choiceEditText;
    private DBManager dbManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pemilih);
        kelasEditText = (EditText) findViewById(R.id.kelas_edittext);
        choiceEditText = (EditText) findViewById(R.id.choice_edittext);
        namaEditText = (EditText) findViewById(R.id.nama_edittext);
        addTodoBtn = (Button) findViewById(R.id.add_record);
        // Membuat objek dari kelas DBManager
        dbManager = new DBManager(this);
        dbManager.open();

    }
    public void save(View view) {
        // Mengambil data inputan user
        final String kelas = kelasEditText.getText().toString();
        final String choice = choiceEditText.getText().toString();
        final String nama = namaEditText.getText().toString();
 /* Memanggil fungsi insert melalui objek dbManager dengan parameter
 nilaikelas dan nama */
        dbManager.insert(kelas, nama, choice);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        alert.setMessage("!!<<PASTIKAN ANDA SUDAH MENGISI SESUAI DESKRIPSI>>!!");

        alert.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg1, int arg2) {
                Toast.makeText(addPemilih.this, "TERIMAKASIH, SILAHKAN KLIK >> TOMBOL KEMBALI <<", Toast.LENGTH_LONG) .show();
            }
        });
        alert.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg1, int arg2) {
                Toast.makeText(addPemilih.this, "Silahkan Isi kembali, atau hubungi panitia", Toast.LENGTH_LONG) .show();
            }
        });

        AlertDialog alertDialog = alert.create();

        alertDialog.show();

    }
    public void selesai(View view) {
        Intent intent = new Intent(addPemilih.this, MainActivity.class);
        startActivity(intent);
    }
}