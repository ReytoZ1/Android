package com.example.aplikasivoting2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.prefs.Preferences;

public class CekDataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cek_data);

        /* Deklarasi dan Menginisialisasi variable nama dengan Label Nama dari Layout MainActivity */
        TextView nama = findViewById(R.id.tv_namaMain);

        /* Men-set Label Nama dengan data User sedang login dari Preferences */
        nama.setText(Preference.getLoggedInUser(getBaseContext()));

        /* Men-set Status dan User yang sedang login menjadi default atau kosong di
         * Data Preferences. Kemudian menuju ke LoginActivity*/
        findViewById(R.id.Logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Menghapus Status login dan kembali ke Login Activity
                Preference.clearLoggedInUser(getBaseContext());
                startActivity(new Intent(getBaseContext(), HasilActivity.class));
                finish();
            }
        });
    }

    public void data(View view) {
        Intent intent = new Intent(CekDataActivity.this, datapemilih.class);
        startActivity(intent);
    }
    public void logout(View view) {
        Intent intent = new Intent(CekDataActivity.this, HasilActivity.class);
        startActivity(intent);
    }
}